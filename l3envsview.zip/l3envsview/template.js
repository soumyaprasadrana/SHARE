module.exports = {
  template: (context, grid, row) => {
    let domContent = ` <div  ng-controller="ctrl">
<style>
  

  .no-record-row {
    background-color: #f8d7da !important;
  }
  .table tbody tr:nth-of-type(odd) {
    background-color: #fff;
  }

  .table tbody tr:nth-of-type(even) {
    background-color: #edf2f7;
  }

  .fa-check {
    color: #28a745;
  }

  .fa-times {
    color: #dc3545;
  }
  .table thead th {
    background-color: var(--mui-btn-primary-background-color) !important;
    color: #333;
  }

  .table-container {
  height: calc(100% - 40px); /* Set the desired height */
  overflow-y: auto; /* Enable vertical scrolling */
}


.table-container table {
  table-layout: fixed; /* Fix the table layout */
}

.table-container thead,
.table-container tbody,
.table-container tr {
  display: table;
  width: 100%;
  table-layout: fixed; /* Fix the table layout */
}

.table-container tbody {
  height: 100%;
  overflow-y: auto; /* Enable vertical scrolling */
}

.table-container td {
  word-break: break-word; /* Allow long text to wrap within cells */
}

.th-width i,.td-width i{
  width: 20px !important;
}
.th-width,.td-width {
  width: 60px;
}

/* Calculate width for first row headers with colspan */
.table tr:nth-of-type(1) th[colspan="2"] {
  width: 120px !important; /* Set the total width of the two columns spanned by the header */
}
.table tr:nth-of-type(1) th[colspan=:"11"] {
  width: 660px !important; /* Set the total width of the two columns spanned by the header */
}
.table tr:nth-of-type(1) th[colspan="4"] {
  width: 240px !important; /* Set the total width of the two columns spanned by the header */
}
.ip-th-width,.ip-td-width{
  width: 160px !important;
  overflow-x : hidden;
}
.ip-td-width span{
  width: 150px !important;
  overflow-x : hidden;
}

.type-th-width,.type-td-width{
  width: 120px !important;
  overflow-x : hidden;
}

.lang-th-width,.lang-td-width{
  width: 100px !important;
  overflow-x : hidden;  
}
</style>
<div class="table-container">
<table class="table  table-responsive">
  <thead class="table-light">
    <tr>
      <th class="ip-th-width">VM IP <input type="text" ng-model="search.vm_ip" class="form-control form-control-sm" /></th>
      <th class="type-th-width">Type <input type="text" ng-model="search.type" class="form-control form-control-sm search-input" /></th>
      <th colspan="2" class="text-center">Maximo IT</th>
      <th colspan="11" class="text-center">ICD</th>
      <th colspan="4" class="text-center">TPAE</th>
      <th class="lang-th-width">Base Lang <input type="text" ng-model="search.baselang" class="form-control form-control-sm search-input" /></th>
      <th class="lang-th-width">Additional Lang <input type="text" ng-model="search.additionallang" class="form-control form-control-sm search-input" /></th>
      <th> </th>
    </tr>
    <tr>
      <th class="ip-th-width"></th>
      <th class="type-th-width"></th>
      <th class="th-width">8.0 <input type="checkbox" ng-model="filter.maximoit80" /></th>
      <th class="th-width">8.1 <input type="checkbox" ng-model="filter.maximoit81" /></th>
      <th class="th-width">7600 <input type="checkbox" ng-model="filter.icd7600" /></th>
      <th class="th-width">7601 <input type="checkbox" ng-model="filter.icd7601" /></th>
      <th class="th-width">7602 <input type="checkbox" ng-model="filter.icd7602" /></th>
      <th class="th-width">7603 <input type="checkbox" ng-model="filter.icd7603" /></th>
      <th class="th-width">7604 <input type="checkbox" ng-model="filter.icd7604" /></th>
      <th class="th-width">7610 <input type="checkbox" ng-model="filter.icd7610" /></th>
      <th class="th-width">7611 <input type="checkbox" ng-model="filter.icd7611" /></th> 
      <th class="th-width">7612 <input type="checkbox" ng-model="filter.icd7612" /></th>
      <th class="th-width">7613 <input type="checkbox" ng-model="filter.icd7613" /></th>
      <th class="th-width">7614 <input type="checkbox" ng-model="filter.icd7614" /></th>
      <th class="th-width">7615 <input type="checkbox" ng-model="filter.icd7615" /></th>
      <th class="th-width">7610 <input type="checkbox" ng-model="filter.tpae7610" /></th>
      <th class="th-width">7611 <input type="checkbox" ng-model="filter.tpae7611" /></th>
      <th class="th-width">7612 <input type="checkbox" ng-model="filter.tpae7612" /></th>
      <th class="th-width">7613 <input type="checkbox" ng-model="filter.tpae7613" /></th>
      
      <th class="lang-th-width"></th>
      <th class="lang-th-width"></th>

      <th><i class="fa fa-plus"/></th>
    </tr>
  </thead>
  <tbody>
    <tr ng-repeat="record in jsonArray | filter:search | filter:customFilter" ng-class="{'no-record-row': (jsonArray | filter:search | filter:customFilter).length === 0}">
      <td class="ip-td-width"><span>{{ record.vm_ip }}</span></td>
      <td class="type-td-width">{{ record.type =='prod'?'Production':record.type=='dev'?'Development':'' }}</td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.maximoit80 === 'true', 'fa-times': record.maximoit80 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.maximoit81 === 'true', 'fa-times': record.maximoit81 === 'false'}"></i></td>
      
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7600 === 'true', 'fa-times': record.icd7600 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7601 === 'true', 'fa-times': record.icd7601 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7602 === 'true', 'fa-times': record.icd7602 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7603 === 'true', 'fa-times': record.icd7603 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7604 === 'true', 'fa-times': record.icd7604 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7610 === 'true', 'fa-times': record.icd7610 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7611 === 'true', 'fa-times': record.icd7611 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7612 === 'true', 'fa-times': record.icd7612 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7613 === 'true', 'fa-times': record.icd7613 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7614 === 'true', 'fa-times': record.icd7614 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.icd7615 === 'true', 'fa-times': record.icd7615 === 'false'}"></i></td>

      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.tpae7610 === 'true', 'fa-times': record.tpae7610 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.tpae7611 === 'true', 'fa-times': record.tpae7611 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.tpae7612 === 'true', 'fa-times': record.tpae7612 === 'false'}"></i></td>
      <td class="td-width"><i class="fa" ng-class="{'fa-check': record.tpae7613 === 'true', 'fa-times': record.tpae7613 === 'false'}"></i></td>
      
      <td class="lang-td-width">{{ record.baselang }}</td>
      <td class="lang-td-width">{{ record.additionallang }}</td>
      
      <td> <i class="fa fa-cog"></td>
    </tr>
    <tr ng-if="(jsonArray | filter:search | filter:customFilter).length === 0" class="no-record-row">
      <td colspan="15" class="text-center">No record found...</td>
    </tr>
  </tbody>
</table>
</div>
  </div>
`;

    return domContent;
  },
};
