module.exports = {
  client: (parent, grid, row, utils) => {
    return {
      //All data members you want to use in template script goes here
      //Enable utils to be accessible inside event bindings
      utils: utils,
      //Custom Function supports angular js , uncomment below properties to enable angular js for your custom function
      //Angular source code should be written inside angularScript; and template's can be defined inside template.js
      //If you want to include any additional libraries you can pass path for the files inside angularJSDependacies list
      // Limitation : You can use angular js route as it is already configured with ANgular's route feature.
      applicationType: "angularjs",
      //angularJSDependacies: [],
      angularScript: (context, utils) => {
        var app = angular.module("app", []);
        app.controller("ctrl", function($scope) {
          $scope.jsonArray = grid;

          $scope.filter = {};
          $scope.customFilter = function(record) {
            // Check if any of the filter checkboxes are selected
            if (
              $scope.filter.maximoit80 ||
              $scope.filter.maximoit81 ||
              $scope.filter.icd7600 ||
              $scope.filter.icd7601 ||
              $scope.filter.icd7602 ||
              $scope.filter.icd7603 ||
              $scope.filter.icd7604 ||
              $scope.filter.icd7610 ||
              $scope.filter.icd7611 ||
              $scope.filter.icd7612 ||
              $scope.filter.icd7613 ||
              $scope.filter.icd7614 ||
              $scope.filter.icd7615 ||
              $scope.filter.tpae7610 ||
              $scope.filter.tpae7611 ||
              $scope.filter.tpae7613 ||
              $scope.filter.tpae7612
            ) {
              // Check the values of the selected checkboxes and return true if the record matches the filter criteria
              return (
                (!$scope.filter.maximoit80 || record.maximoit80 === "true") &&
                (!$scope.filter.maximoit81 || record.maximoit81 === "true") &&
                (!$scope.filter.icd7600 || record.icd7600 === "true") &&
                (!$scope.filter.icd7601 || record.icd7601 === "true") &&
                (!$scope.filter.icd7602 || record.icd7602 === "true") &&
                (!$scope.filter.icd7603 || record.icd7603 === "true") &&
                (!$scope.filter.icd7604 || record.icd7604 === "true") &&
                (!$scope.filter.icd7610 || record.icd7610 === "true") &&
                (!$scope.filter.icd7611 || record.icd7611 === "true") &&
                (!$scope.filter.icd7612 || record.icd7612 === "true") &&
                (!$scope.filter.icd7613 || record.icd7613 === "true") &&
                (!$scope.filter.icd7614 || record.icd7614 === "true") &&
                (!$scope.filter.icd7615 || record.icd7615 === "true") &&
                (!$scope.filter.tpae7610 || record.tpae7610 === "true") &&
                (!$scope.filter.tpae7611 || record.tpae7611 === "true") &&
                (!$scope.filter.tpae7613 || record.tpae7613 === "true") &&
                (!$scope.filter.tpae7612 || record.tpae7612 === "true")
              );
            } else {
              // If no filter checkboxes are selected, return true to include all records
              return true;
            }
          };
        });
      },
      //DO NOT REMOVE BELOW METHOD; IT IS MANDATORY TO BOOTSTRAP YOUR ANGULARJS APPLICATION IF YOU ARE USING DEPENDANCY LIBRRARIES
      //YOU CAN ALWAYS CHANGE BOOTSTRAP SPECIFICATION TO INCLUDE OTHER DEPENDACIES
      angularBootstrapScript: (context, utils) => {
        angular.bootstrap($("#angular-shell"), [ "app" ]);
      },
      // eventBindings : helps to bind event to your template's html dom elements
      /**
            * You can add dom element binding like below; add a property to eventBindings object with the selector
            * You can access client script's return data members
            * domElementSelector : {type:'eventType',event : (context,event)=>{}}
            *
            * 
            * Example you have defined a button in template script with id alertButtton 
            * Build event for this element as below :
            * eventBindings : {
            *   'alertButton' : {
            *                       type: 'click',
            *                       event: (context,event) => { alert(1); }
            *                   }
            * }
            * 
            */
      eventBindings: {},
      /**
             * Life Cycle Event; It will work as a script tag after template is attached to DOM this event will be fired
             * 
             * @param {*} context refers to this > return object from client script
             * @param {*} utils available utils object 
             */
      templateScript: (context, utils) => {},
      /**
             * Life Cycle Event; It will work as a script tag before template is attached to DOM this event will be fired
             * 
             * @param {*} context refers to this > return object from client script
             * @param {*} utils available utils object 
             */
      templateScriptBefore: (context, utils) => {},
    };
  },
};
