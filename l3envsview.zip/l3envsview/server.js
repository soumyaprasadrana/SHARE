module.exports = {
  server: (app) => {
    function handlel3envsviewAPI(req, res, app) {
      return res
        .status(200)
        .send(
          "Awsome! Custom API is listening for user defined function l3envsview..."
        );
    }
    function handlel3envsviewAPIPOST(req, res, app) {
      return res
        .status(200)
        .json(
          {
            text:"Awsome! Custom API is listening for user defined function l3envsview...",
            body: req.body
          }
        );
    }
    app.get("/api/dynamicobjects/userDefinedFunctions/l3envsview/server/get", handlel3envsviewAPI);
    app.post("/api/dynamicobjects/userDefinedFunctions/l3envsview/server/post", handlel3envsviewAPIPOST);
    const express = require("express");
    app.use("/functions/l3envsview/", express.static(__dirname + "/assets"));
  },
};

